

<!-- Iframe2 Section -->
<section id="DailyUsage1" class="testimonials section light-background">

<!-- Section Title -->
<div class="container section-title" data-aos="fade-up">
  <h2>Video Views Stats</h2>
  <p>This section gives you information about the Daily Usage Average of a school within a given timeframe.</p>
</div><!-- End Section Title -->

<div class="container" data-aos="fade-up" data-aos-delay="100">
<iframe id="4VideoViewsStats" src="" dashboardId="e0c744d9-eac8-4d83-baad-2a147a1e8020" width="100%"  frameborder="0" height="400"></iframe>
  </div>

</div>

</section><!-- /Iframe2 Section -->



<!-- Iframe1 Section -->
<section id="contact1" class="contact section">

<!-- Section Title -->
<div class="container section-title" data-aos="fade-up">
  <h2>Geo Mapper</h2>
  <p>This section gives you  information about the general usage of a school within a given timeframe.</p>
</div><!-- End Section Title -->

<div class="container position-relative" data-aos="fade-up" data-aos-delay="100">

  <div class="row gy-4">

    <div class="col-lg-12">
    <iframe id="3GeoMapper" dashboardId="fe9fb56a-4ea4-4339-a57e-a5fab1275cea" src="" width="100%" height="400" frameborder="0"></iframe>
      
    </div><!-- End iframe1 -->

  </div>

</div>

</section><!-- /End Iframe1 Section -->
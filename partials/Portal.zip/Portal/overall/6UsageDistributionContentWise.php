

<!-- Iframe2 Section -->
<section id="DailyUsage2" class="testimonials section light-background">

<!-- Section Title -->
<div class="container section-title" data-aos="fade-up">
  <h2>Usage Distribution ContentWise</h2>
  <p>This section gives you information about the Daily Usage Average of a school within a given timeframe.</p>
</div><!-- End Section Title -->

<div class="container" data-aos="fade-up" data-aos-delay="100">
<iframe id="6UsageDistributionContentWise" src="" dashboardId="bf4800c2-ffbb-43fe-b80a-e9979308d2c4" width="100%"  frameborder="0" height="400"></iframe>
  </div>

</div>

</section><!-- /Iframe2 Section -->

